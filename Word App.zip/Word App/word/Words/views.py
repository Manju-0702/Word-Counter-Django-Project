from django.shortcuts import render

def home(request):
    return render(request, 'home.html')

def count(request):
    if request.method == 'POST':
        text = request.POST['fulltext']
    
        word_list = text.split()
        word_count = len(word_list)

        letter_count = sum(c.isalpha() for c in text)

        vowels = "aeiouAEIOU"
        vowel_count = sum(1 for c in text if c in vowels)

        consonant_count = letter_count - vowel_count

        articles = ['a', 'an', 'the']
        article_count = sum(word.lower() in articles for word in word_list)

        context = {
            'text': text,
            'count': word_count,
            'letter_count': letter_count,
            'vowel_count': vowel_count,
            'consonant_count': consonant_count,
            'article_count': article_count,
        }

        return render(request, 'count.html', context)
